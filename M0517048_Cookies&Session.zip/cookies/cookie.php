<?php

    setcookie("user","Lala",time()+25);

?>