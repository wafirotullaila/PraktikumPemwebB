<?php

$uname = $_POST["uname"];
$pwd = $_POST["pwd"];

if($uname=="admin" && $pwd=="sandi") {
    $_SESSION["user"] =$uname;
    header("Location: file_manager.php");
} else {
    session_unset();
	session_destroy();
    echo "Login Gagal!";
}

?>